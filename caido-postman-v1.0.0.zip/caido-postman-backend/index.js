// src/backend/src/index.ts
function detectAuthentication(headers) {
  const authHeader = headers["authorization"] || headers["Authorization"];
  if (authHeader) {
    if (authHeader.toLowerCase().startsWith("bearer")) {
      return { hasAuth: true, authType: "Bearer Token" };
    }
    if (authHeader.toLowerCase().startsWith("basic")) {
      return { hasAuth: true, authType: "Basic Auth" };
    }
    if (authHeader.toLowerCase().startsWith("digest")) {
      return { hasAuth: true, authType: "Digest Auth" };
    }
    return { hasAuth: true, authType: "Custom Auth" };
  }
  const apiKeyHeaders = ["x-api-key", "api-key", "apikey", "x-auth-token", "x-access-token"];
  for (const key of apiKeyHeaders) {
    if (headers[key] || headers[key.toLowerCase()]) {
      return { hasAuth: true, authType: "API Key" };
    }
  }
  const cookie = headers["cookie"] || headers["Cookie"];
  if (cookie && (cookie.includes("session") || cookie.includes("token") || cookie.includes("auth"))) {
    return { hasAuth: true, authType: "Cookie/Session" };
  }
  return { hasAuth: false, authType: null };
}
function convertToPostmanRequest(request) {
  const urlParts = new URL(request.url);
  const postmanRequest = {
    name: `${request.method} ${request.path}`,
    request: {
      method: request.method,
      header: Object.entries(request.headers).map(([key, value]) => ({
        key,
        value
      })),
      url: {
        raw: request.url,
        protocol: urlParts.protocol.replace(":", ""),
        host: urlParts.hostname.split("."),
        path: urlParts.pathname.split("/").filter((p) => p),
        query: Array.from(urlParts.searchParams.entries()).map(([key, value]) => ({
          key,
          value
        }))
      }
    }
  };
  if (request.body) {
    const contentType = request.headers["content-type"] || request.headers["Content-Type"] || "";
    if (contentType.includes("application/json")) {
      postmanRequest.request.body = {
        mode: "raw",
        raw: request.body
      };
    } else if (contentType.includes("application/x-www-form-urlencoded")) {
      const params = new URLSearchParams(request.body);
      postmanRequest.request.body = {
        mode: "urlencoded",
        urlencoded: Array.from(params.entries()).map(([key, value]) => ({
          key,
          value
        }))
      };
    } else {
      postmanRequest.request.body = {
        mode: "raw",
        raw: request.body
      };
    }
  }
  return postmanRequest;
}
async function sendToPostman(config, request) {
  const postmanRequest = convertToPostmanRequest(request);
  try {
    let collectionId = config.collectionId;
    if (!collectionId) {
      const createCollectionResponse = await fetch(
        "https://api.getpostman.com/collections",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-Api-Key": config.apiKey
          },
          body: JSON.stringify({
            collection: {
              info: {
                name: "Caido Authenticated Requests",
                description: "Requests imported from Caido with authentication - by @OFJAAAH",
                schema: "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
              },
              item: []
            }
          })
        }
      );
      if (!createCollectionResponse.ok) {
        throw new Error(`Failed to create collection: ${createCollectionResponse.statusText}`);
      }
      const collectionData2 = await createCollectionResponse.json();
      collectionId = collectionData2.collection.uid;
    }
    const getCollectionResponse = await fetch(
      `https://api.getpostman.com/collections/${collectionId}`,
      {
        headers: {
          "X-Api-Key": config.apiKey
        }
      }
    );
    if (!getCollectionResponse.ok) {
      throw new Error(`Failed to get collection: ${getCollectionResponse.statusText}`);
    }
    const collectionData = await getCollectionResponse.json();
    collectionData.collection.item.push(postmanRequest);
    const updateResponse = await fetch(
      `https://api.getpostman.com/collections/${collectionId}`,
      {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "X-Api-Key": config.apiKey
        },
        body: JSON.stringify(collectionData)
      }
    );
    if (!updateResponse.ok) {
      throw new Error(`Failed to update collection: ${updateResponse.statusText}`);
    }
    return {
      success: true,
      message: `Request "${postmanRequest.name}" added to Postman collection`,
      collectionUrl: `https://www.postman.com/collections/${collectionId}`
    };
  } catch (error) {
    return {
      success: false,
      message: `Error sending to Postman: ${error instanceof Error ? error.message : String(error)}`
    };
  }
}
function init(sdk) {
  sdk.api.register("filterHistory", async (domain, statusCode, methodFilter) => {
    const requests = [];
    try {
      const findings = await sdk.requests.query({
        filter: {
          and: [
            { host: { cont: domain } }
          ]
        },
        first: 500
      });
      for (const edge of findings.edges) {
        const finding = edge.node;
        const request = finding.request;
        const response = finding.response;
        if (!request || !response) continue;
        if (statusCode && response.code !== statusCode) continue;
        if (methodFilter && methodFilter !== "ALL" && request.method !== methodFilter) continue;
        const headers = {};
        const rawHeaders = request.raw.split("\r\n");
        for (let i = 1; i < rawHeaders.length; i++) {
          const line = rawHeaders[i];
          if (line === "") break;
          const colonIndex = line.indexOf(":");
          if (colonIndex > 0) {
            const key = line.substring(0, colonIndex).trim();
            const value = line.substring(colonIndex + 1).trim();
            headers[key] = value;
          }
        }
        const authInfo = detectAuthentication(headers);
        const bodyStart = request.raw.indexOf("\r\n\r\n");
        const body = bodyStart > 0 ? request.raw.substring(bodyStart + 4) : null;
        const url = `${request.isTls ? "https" : "http"}://${request.host}${request.port !== 80 && request.port !== 443 ? ":" + request.port : ""}${request.path}`;
        requests.push({
          id: finding.id,
          method: request.method,
          url,
          host: request.host,
          path: request.path,
          headers,
          body: body || null,
          statusCode: response.code,
          hasAuth: authInfo.hasAuth,
          authType: authInfo.authType,
          timestamp: finding.createdAt || (/* @__PURE__ */ new Date()).toISOString()
        });
      }
      requests.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      return requests;
    } catch (error) {
      sdk.console.error(`Error filtering history: ${error}`);
      return [];
    }
  });
  sdk.api.register("sendToPostman", async (config, request) => {
    return sendToPostman(config, request);
  });
  sdk.api.register("sendMultipleToPostman", async (config, requests) => {
    let sent = 0;
    let failed = 0;
    const messages = [];
    for (const request of requests) {
      const result = await sendToPostman(config, request);
      if (result.success) {
        sent++;
      } else {
        failed++;
        messages.push(result.message);
      }
    }
    return {
      success: failed === 0,
      message: `Sent ${sent} requests, ${failed} failed${messages.length > 0 ? ": " + messages.join("; ") : ""}`,
      sent,
      failed
    };
  });
  sdk.api.register("testPostmanConnection", async (apiKey) => {
    try {
      const response = await fetch("https://api.getpostman.com/workspaces", {
        headers: {
          "X-Api-Key": apiKey
        }
      });
      if (!response.ok) {
        return {
          success: false,
          message: `API connection failed: ${response.statusText}`
        };
      }
      const data = await response.json();
      return {
        success: true,
        message: "Connected to Postman API successfully",
        workspaces: data.workspaces
      };
    } catch (error) {
      return {
        success: false,
        message: `Connection error: ${error instanceof Error ? error.message : String(error)}`
      };
    }
  });
  sdk.console.log("Caido Postman Integration loaded - by @OFJAAAH");
}
export {
  init
};
