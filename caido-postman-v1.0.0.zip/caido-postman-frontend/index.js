const T = `
<svg class="cp-postman-logo" viewBox="0 0 256 256" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid">
  <circle cx="128" cy="128" r="128" fill="#1a1a1a"/>
  <g transform="translate(28, 28) scale(0.78)">
    <path fill="#FF6C37" d="M128.001 0C57.317 0 0 57.317 0 128.001c0 70.683 57.317 128 128.001 128 70.683 0 128-57.317 128-128C256.001 57.317 198.684 0 128.001 0z"/>
    <path fill="#fff" d="M126.615 116.401l44.85-44.85c1.018-1.018.3-2.761-1.138-2.761h-28.277c-.428 0-.838.17-1.14.473l-31.155 31.155c-.628.628-.184 1.702.702 1.702h14.396c.606 0 1.188-.24 1.617-.669l.145-.05z"/>
    <path fill="#fff" d="M116.565 151.749l44.85-44.85c1.018-1.018.3-2.761-1.138-2.761H132c-.428 0-.838.17-1.14.473l-31.155 31.155c-.628.628-.184 1.702.702 1.702h14.396c.606 0 1.188-.24 1.617-.669l.145-.05z"/>
    <circle fill="#fff" cx="128" cy="126" r="20"/>
  </g>
</svg>
`, $ = `
<svg class="cp-postman-icon" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" width="16" height="16">
  <circle cx="12" cy="12" r="12" fill="#FF6C37"/>
  <path fill="#fff" d="M12 4c-4.4 0-8 3.6-8 8s3.6 8 8 8 8-3.6 8-8-3.6-8-8-8zm0 14c-3.3 0-6-2.7-6-6s2.7-6 6-6 6 2.7 6 6-2.7 6-6 6z"/>
  <circle fill="#fff" cx="12" cy="12" r="3"/>
</svg>
`;
let v = /* @__PURE__ */ new Set(), k = [], i = {
  apiKey: "",
  workspaceId: ""
};
function M() {
  const t = document.createElement("div");
  return t.className = "caido-postman-container", t.innerHTML = `
    <div class="cp-header">
      <div class="cp-logo-section">
        ${T}
        <div class="cp-title-section">
          <h1>Caido -> Postman</h1>
          <span class="cp-author">by @OFJAAAH</span>
        </div>
      </div>
    </div>

    <div class="cp-config-section">
      <div class="cp-config-header" id="configToggle">
        <span>Postman API Configuration</span>
        <span class="cp-toggle-icon">v</span>
      </div>
      <div class="cp-config-body" id="configBody">
        <div class="cp-form-group">
          <label for="postmanApiKey">Postman API Key</label>
          <input type="password" id="postmanApiKey" placeholder="PMAK-..." />
          <small>Get your API key from <a href="https://go.postman.co/settings/me/api-keys" target="_blank">Postman Settings</a></small>
        </div>
        <div class="cp-form-group">
          <label for="postmanWorkspace">Workspace ID</label>
          <input type="text" id="postmanWorkspace" placeholder="workspace-id" />
        </div>
        <div class="cp-form-group">
          <label for="postmanCollection">Collection ID (optional)</label>
          <input type="text" id="postmanCollection" placeholder="collection-id (leave empty to create new)" />
        </div>
        <button id="testConnection" class="cp-btn cp-btn-secondary">
          Test Connection
        </button>
        <div id="connectionStatus" class="cp-status"></div>
      </div>
    </div>

    <div class="cp-filter-section">
      <h2>Filter History</h2>
      <div class="cp-filter-row">
        <div class="cp-form-group">
          <label for="domainFilter">Domain</label>
          <input type="text" id="domainFilter" placeholder="example.com" />
        </div>
        <div class="cp-form-group">
          <label for="statusFilter">Status Code</label>
          <select id="statusFilter">
            <option value="">All</option>
            <option value="200" selected>200 OK</option>
            <option value="201">201 Created</option>
            <option value="204">204 No Content</option>
            <option value="301">301 Redirect</option>
            <option value="400">400 Bad Request</option>
            <option value="401">401 Unauthorized</option>
            <option value="403">403 Forbidden</option>
            <option value="404">404 Not Found</option>
            <option value="500">500 Server Error</option>
          </select>
        </div>
        <div class="cp-form-group">
          <label for="methodFilter">Method</label>
          <select id="methodFilter">
            <option value="ALL">All Methods</option>
            <option value="GET">GET</option>
            <option value="POST" selected>POST</option>
            <option value="PUT">PUT</option>
            <option value="PATCH">PATCH</option>
            <option value="DELETE">DELETE</option>
          </select>
        </div>
      </div>
      <div class="cp-filter-actions">
        <button id="searchBtn" class="cp-btn cp-btn-primary">
          Search Requests
        </button>
        <label class="cp-checkbox">
          <input type="checkbox" id="authOnlyFilter" checked />
          <span>Only authenticated requests</span>
        </label>
      </div>
    </div>

    <div class="cp-results-section">
      <div class="cp-results-header">
        <h2>Results <span id="resultCount">(0)</span></h2>
        <div class="cp-results-actions">
          <button id="selectAllBtn" class="cp-btn cp-btn-small">Select All</button>
          <button id="sendSelectedBtn" class="cp-btn cp-btn-postman" disabled>
            ${$} Send Selected to Postman
          </button>
        </div>
      </div>
      <div id="resultsTable" class="cp-results-table">
        <div class="cp-empty-state">
          <p>Enter a domain and click "Search Requests" to filter history</p>
        </div>
      </div>
    </div>

    <div id="requestModal" class="cp-modal" style="display: none;">
      <div class="cp-modal-content">
        <div class="cp-modal-header">
          <h3>Request Details</h3>
          <button class="cp-modal-close">x</button>
        </div>
        <div class="cp-modal-body" id="modalBody"></div>
        <div class="cp-modal-footer">
          <button id="sendSingleBtn" class="cp-btn cp-btn-postman">
            ${$} Send to Postman
          </button>
        </div>
      </div>
    </div>

    <div id="toast" class="cp-toast"></div>
  `, t;
}
function d(t, o = "info") {
  const s = document.getElementById("toast");
  s && (s.textContent = t, s.className = `cp-toast cp-toast-${o} cp-toast-show`, setTimeout(() => {
    s.className = "cp-toast";
  }, 3e3));
}
function F(t) {
  return Object.entries(t).map(([o, s]) => `${o}: ${s}`).join(`
`);
}
function R(t) {
  if (!t) return "(empty)";
  try {
    const o = JSON.parse(t);
    return JSON.stringify(o, null, 2);
  } catch {
    return t;
  }
}
function B(t, o) {
  const s = document.getElementById("resultsTable"), h = document.getElementById("resultCount"), p = document.getElementById("sendSelectedBtn");
  if (!s || !h) return;
  const r = o ? t.filter((c) => c.hasAuth) : t;
  if (k = r, h.textContent = `(${r.length})`, v.clear(), p.disabled = !0, r.length === 0) {
    s.innerHTML = `
      <div class="cp-empty-state">
        <p>No requests found matching your criteria</p>
      </div>
    `;
    return;
  }
  s.innerHTML = `
    <table class="cp-table">
      <thead>
        <tr>
          <th class="cp-col-checkbox"><input type="checkbox" id="selectAllCheckbox" /></th>
          <th class="cp-col-method">Method</th>
          <th class="cp-col-status">Status</th>
          <th class="cp-col-path">Path</th>
          <th class="cp-col-auth">Auth</th>
          <th class="cp-col-actions">Actions</th>
        </tr>
      </thead>
      <tbody>
        ${r.map((c) => `
          <tr data-id="${c.id}">
            <td><input type="checkbox" class="cp-row-checkbox" data-id="${c.id}" /></td>
            <td><span class="cp-method cp-method-${c.method.toLowerCase()}">${c.method}</span></td>
            <td><span class="cp-status cp-status-${Math.floor(c.statusCode / 100)}xx">${c.statusCode}</span></td>
            <td class="cp-path" title="${c.url}">${c.path}</td>
            <td>
              ${c.hasAuth ? `<span class="cp-auth-badge">${c.authType}</span>` : '<span class="cp-no-auth">None</span>'}
            </td>
            <td>
              <button class="cp-btn cp-btn-small cp-btn-view" data-id="${c.id}">View</button>
              <button class="cp-btn cp-btn-small cp-btn-send" data-id="${c.id}">Send</button>
            </td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  `;
}
function H(t) {
  const o = document.getElementById("requestModal"), s = document.getElementById("modalBody");
  !o || !s || (s.innerHTML = `
    <div class="cp-request-detail">
      <div class="cp-detail-section">
        <h4>Request</h4>
        <div class="cp-detail-row">
          <strong>URL:</strong>
          <code>${t.url}</code>
        </div>
        <div class="cp-detail-row">
          <strong>Method:</strong>
          <span class="cp-method cp-method-${t.method.toLowerCase()}">${t.method}</span>
        </div>
        <div class="cp-detail-row">
          <strong>Status:</strong>
          <span class="cp-status cp-status-${Math.floor(t.statusCode / 100)}xx">${t.statusCode}</span>
        </div>
        ${t.hasAuth ? `
          <div class="cp-detail-row">
            <strong>Authentication:</strong>
            <span class="cp-auth-badge">${t.authType}</span>
          </div>
        ` : ""}
      </div>

      <div class="cp-detail-section">
        <h4>Headers</h4>
        <pre class="cp-code">${F(t.headers)}</pre>
      </div>

      <div class="cp-detail-section">
        <h4>Body</h4>
        <pre class="cp-code">${R(t.body)}</pre>
      </div>
    </div>
  `, o.style.display = "flex", o.dataset.requestId = t.id);
}
function N(t) {
  const o = document.getElementById("configToggle"), s = document.getElementById("configBody");
  o == null || o.addEventListener("click", () => {
    s == null || s.classList.toggle("cp-config-collapsed");
    const e = o.querySelector(".cp-toggle-icon");
    e && (e.textContent = s != null && s.classList.contains("cp-config-collapsed") ? ">" : "v");
  });
  const h = document.getElementById("postmanApiKey"), p = document.getElementById("postmanWorkspace"), r = document.getElementById("postmanCollection");
  [h, p, r].forEach((e) => {
    e == null || e.addEventListener("change", () => {
      i = {
        apiKey: (h == null ? void 0 : h.value) || "",
        workspaceId: (p == null ? void 0 : p.value) || "",
        collectionId: (r == null ? void 0 : r.value) || void 0
      }, localStorage.setItem("caido-postman-config", JSON.stringify(i));
    });
  });
  const c = localStorage.getItem("caido-postman-config");
  if (c)
    try {
      i = JSON.parse(c), h && (h.value = i.apiKey), p && (p.value = i.workspaceId), r && (r.value = i.collectionId || "");
    } catch {
    }
  const f = document.getElementById("testConnection"), w = document.getElementById("connectionStatus");
  f == null || f.addEventListener("click", async () => {
    if (!i.apiKey) {
      d("Please enter your Postman API key", "error");
      return;
    }
    f.textContent = "Testing...", f.setAttribute("disabled", "true");
    try {
      const e = await t.backend.testPostmanConnection(i.apiKey);
      w && (w.className = `cp-status cp-status-${e.success ? "success" : "error"}`, w.textContent = e.message, e.success && e.workspaces && e.workspaces.length > 0 && !i.workspaceId && p && (p.value = e.workspaces[0].id, i.workspaceId = e.workspaces[0].id, localStorage.setItem("caido-postman-config", JSON.stringify(i)))), d(e.message, e.success ? "success" : "error");
    } catch (e) {
      d(`Connection failed: ${e}`, "error");
    } finally {
      f.textContent = "Test Connection", f.removeAttribute("disabled");
    }
  });
  const g = document.getElementById("searchBtn"), x = document.getElementById("domainFilter"), I = document.getElementById("statusFilter"), C = document.getElementById("methodFilter"), y = document.getElementById("authOnlyFilter");
  g == null || g.addEventListener("click", async () => {
    var n;
    const e = (n = x == null ? void 0 : x.value) == null ? void 0 : n.trim();
    if (!e) {
      d("Please enter a domain to filter", "error");
      return;
    }
    g.textContent = "Searching...", g.setAttribute("disabled", "true");
    try {
      const l = I != null && I.value ? parseInt(I.value) : void 0, u = (C == null ? void 0 : C.value) || "ALL", m = await t.backend.filterHistory(e, l, u);
      B(m, (y == null ? void 0 : y.checked) ?? !0), d(`Found ${m.length} requests`, "success");
    } catch (l) {
      d(`Search failed: ${l}`, "error");
    } finally {
      g.textContent = "Search Requests", g.removeAttribute("disabled");
    }
  }), y == null || y.addEventListener("change", () => {
    k.length > 0 && B(k, y.checked);
  });
  const b = document.getElementById("resultsTable"), E = document.getElementById("sendSelectedBtn");
  b == null || b.addEventListener("click", async (e) => {
    const n = e.target;
    if (n.classList.contains("cp-btn-view")) {
      const l = n.dataset.id, u = k.find((m) => m.id === l);
      u && H(u);
    }
    if (n.classList.contains("cp-btn-send")) {
      const l = n.dataset.id, u = k.find((m) => m.id === l);
      u && await L(t, u);
    }
  }), b == null || b.addEventListener("change", (e) => {
    const n = e.target;
    if (n.classList.contains("cp-row-checkbox")) {
      const l = n.dataset.id;
      l && (n.checked ? v.add(l) : v.delete(l), E.disabled = v.size === 0);
    }
    n.id === "selectAllCheckbox" && (b.querySelectorAll(".cp-row-checkbox").forEach((u) => {
      u.checked = n.checked;
      const m = u.dataset.id;
      m && (n.checked ? v.add(m) : v.delete(m));
    }), E.disabled = v.size === 0);
  });
  const A = document.getElementById("selectAllBtn");
  A == null || A.addEventListener("click", () => {
    const e = document.getElementById("selectAllCheckbox");
    e && (e.checked = !e.checked, e.dispatchEvent(new Event("change", { bubbles: !0 })));
  }), E == null || E.addEventListener("click", async () => {
    const e = k.filter((n) => v.has(n.id));
    e.length !== 0 && await K(t, e);
  });
  const a = document.getElementById("requestModal"), S = a == null ? void 0 : a.querySelector(".cp-modal-close"), P = document.getElementById("sendSingleBtn");
  S == null || S.addEventListener("click", () => {
    a && (a.style.display = "none");
  }), a == null || a.addEventListener("click", (e) => {
    e.target === a && (a.style.display = "none");
  }), P == null || P.addEventListener("click", async () => {
    const e = a == null ? void 0 : a.dataset.requestId, n = k.find((l) => l.id === e);
    n && (await L(t, n), a && (a.style.display = "none"));
  });
}
async function L(t, o) {
  if (!i.apiKey) {
    d("Please configure your Postman API key first", "error");
    return;
  }
  d("Sending to Postman...", "info");
  try {
    const s = await t.backend.sendToPostman(i, o);
    d(s.message, s.success ? "success" : "error");
  } catch (s) {
    d(`Failed to send: ${s}`, "error");
  }
}
async function K(t, o) {
  if (!i.apiKey) {
    d("Please configure your Postman API key first", "error");
    return;
  }
  d(`Sending ${o.length} requests to Postman...`, "info");
  try {
    const s = await t.backend.sendMultipleToPostman(i, o);
    d(s.message, s.success ? "success" : "error");
  } catch (s) {
    d(`Failed to send: ${s}`, "error");
  }
}
function O(t) {
  const o = M();
  t.navigation.addPage("/postman", {
    body: o,
    topbar: () => {
      const s = document.createElement("div");
      return s.innerHTML = `<span style="display: flex; align-items: center; gap: 8px;">${$} Postman Integration</span>`, s;
    }
  }), t.sidebar.registerItem("Postman", "/postman", {
    icon: "rocket",
    group: "Tools"
  }), t.commands.register("postman:open", {
    name: "Open Postman Integration",
    run: () => t.navigation.goTo("/postman")
  }), setTimeout(() => {
    N(t);
  }, 100), t.console.log("Caido Postman Integration initialized - by @OFJAAAH");
}
export {
  O as init
};
